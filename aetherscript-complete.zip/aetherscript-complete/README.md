# AetherScript

JavaScript で実装された軽量スクリプト言語。  
Flow（リアクティブストリーム）を言語レベルでサポートするのが特徴。

## クイックスタート

```bash
# ファイルを実行
node aether.js run examples/todo.ae

# 対話モード（REPL）
node aether.js repl

# パッケージをインストール
node aether.js install <package>

# テストスイートを実行
node test_runner.js
```

## 言語仕様

### 変数・型

```
let x: number = 42
let name: string = "Alice"
let flag: boolean = true
let val = null
```

型アノテーションは省略可能。型が指定された場合は実行時にチェックされる。

### 関数

```
fn add(a: number, b: number): number {
  return a + b
}

// デフォルト引数
fn greet(name, prefix) {
  if (prefix == null) { prefix = "Hello" }
  return `${prefix}, ${name}!`
}

// 無名関数（クロージャ）
let double = fn(x) { return x * 2 }
```

### 制御フロー

```
// if / else if / else
if (x > 0) {
  print("positive")
} else if (x == 0) {
  print("zero")
} else {
  print("negative")
}

// while
while (i < 10) {
  i++
}

// for（C スタイル）
for (let i = 0; i < 10; i++) {
  print(i)
}

// for...of（イテレーション）
for (let item of [1, 2, 3]) {
  print(item)
}

// switch
switch (grade) {
  case "A": print("優秀") break
  case "B": print("良好") break
  default:  print("その他")
}
```

### 配列・オブジェクト

```
// 配列
let arr = [1, 2, 3]
let [a, b, c] = arr        // 分割代入

// オブジェクト
let user = { name: "Alice", age: 30 }
let updated = { ...user, age: 31 }  // スプレッド
```

### 例外処理

```
try {
  throw "エラーメッセージ"
} catch (e) {
  print(e)
}
```

### テンプレートリテラル

```
let name = "World"
print(`Hello, ${name}!`)
print(`1 + 2 = ${1 + 2}`)
```

### 非同期処理

```
import time

// sleep（async 透過実行 — 構文変更なし）
time.sleep(1000)
print("1秒後")
```

### Flow（リアクティブストリーム）

```
import time

// interval で定期 emit
flow tick = interval(1000)

// チェーン
flow count = tick
  .map(fn(v) { return 1 })
  .scan(fn(a, b) { return a + b }, 0)
  .filter(fn(n) { return n % 2 == 0 })

// 購読
let unsub = count.subscribe(fn(v) {
  print(`偶数カウント: ${v}`)
})

// Promise → Flow
flow result = fromPromise(time.sleep(500))
result.subscribe(fn(v) { print("完了") })
```

### モジュールシステム

```
// 標準ライブラリ
import "@math"    // math.sqrt, math.floor など
import string     // string.upper, string.split など
import array      // array.push, array.range など
import time       // time.now, time.sleep
import fs         // fs.read, fs.write
import http       // http.get, http.getFlow

// ローカルファイル
import "./mymodule"

// パッケージ（registry.json に登録済み）
// node aether.js install mypackage
import mypackage
```

## 標準ライブラリ

### math（`import "@math"`）
`abs` `floor` `ceil` `round` `sqrt` `pow` `max` `min` `random` `randInt` `PI`

### string（`import string`）
`length` `upper` `lower` `trim` `slice` `split` `includes` `replace` `concat` `repeat`

### array（`import array`）
`push` `pop` `shift` `unshift` `length` `get` `set` `slice` `includes` `join` `reverse` `empty` `range`

### time（`import time`）
`now` `sleep` `format`

### fs（`import fs`）
`read` `write` `exists` `remove`

### http（`import http`）
`get` `post` `getFlow` `pollFlow`

### core（`import core`）
`type` `toString` `toNumber` `identity`

## ファイル構成

```
aether.js          CLIエントリポイント（run / repl / install）
parser.js          Tokenizer + 再帰下降パーサー → AST
interpreter.js     ASTインタプリタ（async対応）
flow.js            Flowエンジン
stdlib.js          標準ライブラリ
http.js            HTTP モジュール
install.js         パッケージマネージャ
repl.js            REPL（対話モード）
registry.json      パッケージレジストリ
test_runner.js     自動テストスイート（69件）

examples/
  todo.ae          Todoアプリ + FizzBuzz
  data_pipeline.ae HTTP→加工→ファイル保存
  csv_report.ae    CSV集計レポート
  monitor.ae       Flowリアルタイム監視

vscode-aether/     VSCode シンタックスハイライト拡張
```

## VSCode 拡張のインストール

```bash
# 開発モード（F5キーで起動）
# vscode-aether/ フォルダを VSCode で開いて F5

# VSIX パッケージとしてインストール
npm install -g @vscode/vsce
cd vscode-aether
vsce package
code --install-extension aetherscript-0.1.0.vsix
```

## テスト

```bash
node test_runner.js          # 全件実行
node test_runner.js --fast   # 失敗時即停止
```
