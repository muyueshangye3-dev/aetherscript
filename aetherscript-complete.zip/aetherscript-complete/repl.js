/**
 * AetherScript REPL（対話モード）
 *
 * 使い方: node aether.js repl
 *
 * 機能:
 *   - 1行ずつ入力して即実行
 *   - 複数行入力（{ が開いていれば次の行を待つ）
 *   - 前の変数・関数が次の入力でも使える（env を持続）
 *   - .exit / Ctrl+C で終了
 *   - .clear で env をリセット
 *   - .help でコマンド一覧
 */

'use strict';

const readline = require('readline');
const { parseAetherScript } = require('./parser');
const { evalNode, createGlobalEnv, formatError } = require('./interpreter');

// ─── ブレース対応バランスチェック ─────────────────────────────────

/**
 * 開いた { の数と閉じた } の数を数えて
 * まだブロックが閉じていないかどうかを返す
 * 文字列内の { } は無視する
 */
function isIncomplete(src) {
  let depth  = 0;
  let inStr  = null;   // null | '"' | "'"
  for (const ch of src) {
    if (inStr) {
      if (ch === inStr) inStr = null;
    } else if (ch === '"' || ch === "'") {
      inStr = ch;
    } else if (ch === '{' || ch === '(') {
      depth++;
    } else if (ch === '}' || ch === ')') {
      depth--;
    }
  }
  return depth > 0;
}

// ─── REPL メイン ──────────────────────────────────────────────────

async function startRepl() {
  // 持続する env（セッション全体で共有）
  const env = createGlobalEnv();

  const isTTY = process.stdin.isTTY;
  const rl = readline.createInterface({
    input:    process.stdin,
    output:   process.stdout,
    prompt:   'aether> ',
    terminal: isTTY,     // TTY でないときはエコーなし（パイプ・テスト用）
  });

  console.log([
    '',
    '  \x1b[1m\x1b[36mAetherScript REPL v0.1\x1b[0m',
    '  .help でコマンド一覧  /  .exit または Ctrl+C で終了',
    '',
  ].join('\n'));

  rl.prompt();

  let buffer = '';   // 複数行バッファ

  rl.on('line', async (line) => {
    // ── REPL コマンド ────────────────────────────────────────────
    const trimmed = line.trim();

    if (buffer === '' && trimmed === '.exit') {
      console.log('bye!');
      rl.close();
      process.exit(0);
    }

    if (buffer === '' && trimmed === '.clear') {
      // env を初期状態に戻す
      for (const key of Object.keys(env)) delete env[key];
      Object.assign(env, createGlobalEnv());
      console.log('\x1b[33m[cleared]\x1b[0m');
      rl.setPrompt('aether> ');
      rl.prompt();
      return;
    }

    if (buffer === '' && trimmed === '.help') {
      console.log([
        '',
        '  \x1b[1mREPL コマンド\x1b[0m',
        '  .exit    終了',
        '  .clear   変数・関数をリセット',
        '  .help    このヘルプを表示',
        '',
        '  \x1b[1m複数行入力\x1b[0m',
        '  { が開いていると自動で続行プロンプト (...) になります',
        '  空行で強制確定します',
        '',
      ].join('\n'));
      rl.prompt();
      return;
    }

    // ── バッファに追記 ────────────────────────────────────────────
    buffer += (buffer ? '\n' : '') + line;

    // 空行 → 強制確定（複数行の終わり）
    if (trimmed === '' && buffer.trim() === '') {
      buffer = '';
      rl.setPrompt('aether> ');
      rl.prompt();
      return;
    }

    // ブロックが閉じていなければ続行プロンプトへ
    if (isIncomplete(buffer)) {
      rl.setPrompt('...     ');
      rl.prompt();
      return;
    }

    // ── 入力確定 → 実行 ──────────────────────────────────────────
    const src = buffer;
    buffer = '';
    rl.setPrompt('aether> ');

    try {
      const ast    = parseAetherScript(src);
      const result = await evalNode({ type: 'Program', body: ast.body }, env);
      if (result !== undefined && result !== null) {
        console.log('\x1b[32m=>\x1b[0m', format(result));
      }
    } catch (e) {
      // REPL では行番号付きエラー + ソース行を表示
      if (e.line) {
        console.error(formatError(e, '<repl>', src));
      } else {
        console.error(`\x1b[31m[error]\x1b[0m ${e.message}`);
      }
    }

    rl.prompt();
  });

  rl.on('close', () => {
    console.log('\nbye!');
    process.exit(0);
  });
}

/**
 * REPL 結果の表示フォーマット
 * 配列・オブジェクトは JSON 風に表示する
 */
function format(value) {
  if (Array.isArray(value))               return '[' + value.map(format).join(', ') + ']';
  if (typeof value === 'string')          return `"${value}"`;
  if (typeof value === 'function')        return '[function]';
  if (value !== null && typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

module.exports = { startRepl };
