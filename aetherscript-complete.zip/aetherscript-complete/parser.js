/**
 * AetherScript Parser v1
 * Tokenizer → 再帰下降パーサー → AST
 */

const path = require('path');

const KEYWORDS = new Set([
  'let', 'fn', 'return', 'flow', 'import',
  'try', 'catch', 'throw',
  'if', 'else',
  'while', 'for', 'of', 'break', 'continue',
  'switch', 'case', 'default',
  'true', 'false', 'null',
]);

function tokenize(src) {
  const tokens = [];
  let i    = 0;
  let line = 1;   // 1-based
  let col  = 1;   // 1-based

  // pos → { line, col } を逆引きするテーブルを作る
  // （エラー時に any pos から行列を出せるよう）
  const posToLC = [];
  {
    let l = 1, c = 1;
    for (let k = 0; k < src.length; k++) {
      posToLC[k] = { line: l, col: c };
      if (src[k] === '\n') { l++; c = 1; } else { c++; }
    }
    posToLC[src.length] = { line: l, col: c };  // EOF 用
  }

  const mkTok = (type, value, pos) => ({
    type, value, pos,
    line: posToLC[pos]?.line ?? 1,
    col:  posToLC[pos]?.col  ?? 1,
  });

  while (i < src.length) {
    // 空白・改行スキップ
    if (/\s/.test(src[i])) { i++; continue; }

    // 行コメント
    if (src[i] === '/' && src[i + 1] === '/') {
      while (i < src.length && src[i] !== '\n') i++;
      continue;
    }

    const pos = i;

    // 数値
    if (/[0-9]/.test(src[i])) {
      let num = '';
      while (i < src.length && /[0-9.]/.test(src[i])) num += src[i++];
      tokens.push(mkTok('number', Number(num), pos));
      continue;
    }

    // 文字列（エスケープシーケンス対応）
    if (src[i] === '"' || src[i] === "'") {
      const quote = src[i++];
      let str = '';
      while (i < src.length && src[i] !== quote) {
        if (src[i] === '\\') {
          i++;  // バックスラッシュを消費
          switch (src[i]) {
            case 'n':  str += '\n'; break;
            case 't':  str += '\t'; break;
            case 'r':  str += '\r'; break;
            case '\\': str += '\\'; break;
            case '"':  str += '"';  break;
            case "'":  str += "'";  break;
            case '0':  str += '\0'; break;
            default:   str += src[i]; break;  // 未知のエスケープはそのまま
          }
          i++;
        } else {
          str += src[i++];
        }
      }
      if (i >= src.length) throw new SyntaxError(`文字列が閉じられていません (${posToLC[pos].line}:${posToLC[pos].col})`);
      i++;
      tokens.push(mkTok('string', str, pos));
      continue;
    }

    // 識別子 / キーワード
    if (/[a-zA-Z_]/.test(src[i])) {
      let word = '';
      while (i < src.length && /[a-zA-Z0-9_]/.test(src[i])) word += src[i++];
      tokens.push(mkTok(KEYWORDS.has(word) ? 'keyword' : 'identifier', word, pos));
      continue;
    }

    // バッククォート文字列（テンプレートリテラル `hello ${name}`）
    if (src[i] === '`') {
      const start = i++;
      let raw = '';
      while (i < src.length && src[i] !== '`') {
        if (src[i] === '\\') { raw += src[i++]; }
        raw += src[i++];
      }
      if (i >= src.length) throw new SyntaxError(`テンプレート文字列が閉じられていません (${posToLC[start].line}:${posToLC[start].col})`);
      i++;
      tokens.push(mkTok('template', raw, start));
      continue;
    }

    // 演算子（2文字を先に判定してから1文字へ）
    if (/[+\-*\/=!<>&|]/.test(src[i])) {
      const two = src[i] + src[i+1];
      if (['+=', '-=', '*=', '/=', '==', '!=', '<=', '>=', '&&', '||', '++', '--'].includes(two)) {
        tokens.push(mkTok('operator', two, pos));
        i += 2;
      } else {
        tokens.push(mkTok('operator', src[i++], pos));
      }
      continue;
    }

    // 区切り文字
    if (/[(){},.:[\];]/.test(src[i])) {
      tokens.push(mkTok('punctuation', src[i++], pos));
      continue;
    }

    const lc = posToLC[i];
    throw new SyntaxError(`未知の文字: "${src[i]}" (${lc.line}:${lc.col})`);
  }

  tokens.push(mkTok('eof', null, i));
  return tokens;
}

function parse(tokens) {
  let pos = 0;

  const peek    = ()           => tokens[pos];
  const advance = ()           => tokens[pos++];
  const isEof   = ()           => peek().type === 'eof';
  const check   = (type, val)  => { const t = peek(); return t.type === type && (val === undefined || t.value === val); };

  const expect = (type, val) => {
    const t = peek();
    if (t.type !== type || (val !== undefined && t.value !== val)) {
      const got = t.type === 'eof' ? 'ファイルの終わり' : `"${t.value}"`;
      const exp = val !== undefined ? `"${val}"` : type;
      throw new SyntaxError(
        `${t.line}:${t.col}: ${exp} が必要ですが ${got} がありました`
      );
    }
    return advance();
  };

  // ── 文 ──────────────────────────────────────────────────────

  function parseProgram() {
    const body = [];
    while (!isEof()) body.push(parseStatement());
    return { type: 'Program', body };
  }

  function parseStatement() {
    const t = peek();
    if (t.type === 'keyword') {
      if (t.value === 'let')    return parseVarDecl();
      if (t.value === 'fn')     return parseFunctionDecl();
      if (t.value === 'return') return parseReturnStmt();
      if (t.value === 'flow')   return parseFlowDecl();
      if (t.value === 'import') return parseImportDecl();
      if (t.value === 'try')    return parseTryCatch();
      if (t.value === 'throw')  return parseThrow();
      if (t.value === 'if')       return parseIfStmt();
      if (t.value === 'while')    return parseWhileStmt();
      if (t.value === 'for')      return parseForStmt();
      if (t.value === 'break')    { advance(); return { type: 'BreakStmt' }; }
      if (t.value === 'continue') { advance(); return { type: 'ContinueStmt' }; }
      if (t.value === 'switch')   return parseSwitchStmt();
    }

    // 再代入・複合代入・インクリメント: name = / name += / name++ など
    if (t.type === 'identifier') {
      const next = tokens[pos + 1];
      if (next && next.type === 'operator') {
        if (next.value === '=')                          return parseAssignStmt();
        if (['+=','-=','*=','/='].includes(next.value)) return parseCompoundAssign();
        if (next.value === '++' || next.value === '--')  return parseIncDec();
      }
    }

    return parseExpression();
  }

  /**
   * for (let x of arr) { body }      ← ForOfStmt
   * for (let i = 0; i < n; i++) { }  ← ForStmt
   *
   * ( の直後が let/識別子 + of なら ForOf、それ以外は従来の ForStmt
   */
  function parseForStmt() {
    expect('keyword', 'for');
    expect('punctuation', '(');

    // for...of 判定: let x of / x of
    const p0 = tokens[pos];
    const p1 = tokens[pos + 1];
    const p2 = tokens[pos + 2];
    const isForOf =
      (p0.value === 'let' && p2 && p2.type === 'keyword' && p2.value === 'of') ||
      (p0.type === 'identifier' && p1 && p1.type === 'keyword' && p1.value === 'of');

    if (isForOf) return parseForOfStmt();
    return parseForCStmt();
  }

  /**
   * for (let x of iterable) { body }
   * AST: { type: 'ForOfStmt', varName, iterable, body }
   */
  function parseForOfStmt() {
    const hasLet = check('keyword', 'let');
    if (hasLet) advance();
    const varName = expect('identifier').value;
    expect('keyword', 'of');
    const iterable = parseExpression();
    expect('punctuation', ')');
    const body = parseBlock();
    return { type: 'ForOfStmt', varName, iterable, body };
  }

  /**
   * for (let i = 0; i < n; i++) { body }
   */
  function parseForCStmt() {
    let init = null;
    if (!check('punctuation', ';')) {
      if (check('keyword', 'let')) {
        init = parseVarDecl();
      } else {
        init = parseAssignStmt();
      }
    }
    expect('punctuation', ';');

    const condition = check('punctuation', ';') ? null : parseExpression();
    expect('punctuation', ';');

    let update = null;
    if (!check('punctuation', ')')) {
      const uName = peek();
      if (uName.type === 'identifier') {
        const uNext = tokens[pos + 1];
        if (uNext && uNext.type === 'operator') {
          if (uNext.value === '++' || uNext.value === '--') {
            update = parseIncDec();
          } else if (['+=','-=','*=','/='].includes(uNext.value)) {
            update = parseCompoundAssign();
          } else {
            update = parseAssignStmt();
          }
        } else {
          update = parseAssignStmt();
        }
      }
    }
    expect('punctuation', ')');
    const body = parseBlock();
    return { type: 'ForStmt', init, condition, update, body };
  }

  /**
   * 変数再代入: name = expr
   * AST: { type: 'AssignStmt', name: string, value: <expr> }
   *
   * 注: let 宣言とは別。既存変数への上書きのみ。
   */
  function parseAssignStmt() {
    const name = expect('identifier').value;
    expect('operator', '=');
    const value = parseExpression();
    return { type: 'AssignStmt', name, value };
  }

  /**
   * 複合代入: name += expr  name -= expr  name *= expr  name /= expr
   * AST: { type: 'CompoundAssign', name, op, value }
   * 実行時: name = name op value に展開する
   */
  function parseCompoundAssign() {
    const name = expect('identifier').value;
    const op   = advance().value;   // +=  -=  *=  /=
    const value = parseExpression();
    return { type: 'CompoundAssign', name, op, value };
  }

  /**
   * インクリメント/デクリメント文: name++  name--
   * AST: { type: 'IncDecStmt', name, op }
   */
  function parseIncDec() {
    const name = expect('identifier').value;
    const op   = advance().value;   // ++ or --
    return { type: 'IncDecStmt', name, op };
  }

  /**
   * switch (expr) { case v: ... default: ... }
   *
   * AST:
   * {
   *   type:    'SwitchStmt',
   *   expr:    <expr>,
   *   cases:   [{ value: <expr>|null, body: [...stmts] }]
   *            value=null は default ケース
   * }
   */
  function parseSwitchStmt() {
    expect('keyword', 'switch');
    expect('punctuation', '(');
    const expr = parseExpression();
    expect('punctuation', ')');
    expect('punctuation', '{');

    const cases = [];
    while (!check('punctuation', '}')) {
      let value = null;
      if (check('keyword', 'case')) {
        advance();
        value = parseExpression();
        expect('punctuation', ':');
      } else if (check('keyword', 'default')) {
        advance();
        expect('punctuation', ':');
      } else {
        throw new SyntaxError(`switch 内に case または default が必要です`);
      }

      // 次の case/default/} まで文を収集
      const body = [];
      while (
        !check('punctuation', '}') &&
        !check('keyword', 'case') &&
        !check('keyword', 'default')
      ) {
        body.push(parseStatement());
      }
      cases.push({ value, body });
    }
    expect('punctuation', '}');
    return { type: 'SwitchStmt', expr, cases };
  }

  function parseVarDecl() {
    const kw = expect('keyword', 'let');

    // 配列分割代入: let [a, b] = expr
    if (check('punctuation', '[')) {
      advance();
      const names = [];
      while (!check('punctuation', ']')) {
        names.push(expect('identifier').value);
        if (!check('punctuation', ']')) expect('punctuation', ',');
      }
      expect('punctuation', ']');
      expect('operator', '=');
      const init = parseExpression();
      return { type: 'ArrayDestructure', names, init, line: kw.line, col: kw.col };
    }

    // 通常宣言: let x: type = expr
    const nameTok      = expect('identifier');
    const typeAnnotation = check('punctuation', ':') ? (advance(), parseTypeAnnotation()) : null;
    expect('operator', '=');
    return {
      type: 'VarDecl', name: nameTok.value,
      typeAnnotation, init: parseExpression(),
      line: nameTok.line, col: nameTok.col,
    };
  }

  function parseFlowDecl() {
    expect('keyword', 'flow');
    const name = expect('identifier').value;
    expect('operator', '=');
    return { type: 'FlowDecl', name, init: parseExpression() };
  }

  // import math  または  import "./path/to/math"
  function parseImportDecl() {
    expect('keyword', 'import');
    const t = peek();
    // import math  → モジュール名を識別子で指定（"math.ae" を自動解決）
    if (t.type === 'identifier') {
      const name = advance().value;                  // バインド名 = ファイル名
      return { type: 'ImportDecl', name, source: name };
    }
    // import "./utils" または import "@math"（stdlib強制）→ パス文字列で指定
    if (t.type === 'string') {
      const source = advance().value;
      // "@math" → バインド名は "math"、"./utils" → "utils"
      const base = path.basename(source).replace(/\.ae$/, '');
      const name = base.startsWith('@') ? base.slice(1) : base;
      return { type: 'ImportDecl', name, source };
    }
    throw new SyntaxError(`importの後には識別子か文字列が必要です (pos ${t.pos})`);
  }

  function parseFunctionDecl() {
    const kw     = expect('keyword', 'fn');
    const nameTok = check('punctuation', '(') ? null : expect('identifier');
    const params  = parseParamList();
    const returnType = check('punctuation', ':') ? (advance(), parseTypeAnnotation()) : null;
    const body = parseBlock();
    return {
      type: 'FunctionDecl',
      name: nameTok ? nameTok.value : null,
      params, returnType, body,
      line: (nameTok ?? kw).line,
      col:  (nameTok ?? kw).col,
    };
  }

  /**
   * パラメータリスト: (a, b)  または  (a: number, b: string)
   * 戻り値: 後方互換のため params は文字列配列のままにせず
   *         { name, typeAnnotation } オブジェクト配列に変更する。
   *         evalNode 側で node.params[i].name を使うよう対応する。
   */
  function parseParamList() {
    expect('punctuation', '(');
    const params = [];
    while (!check('punctuation', ')')) {
      let rest = false;
      if (check('punctuation', '.')) {
        expect('punctuation', '.'); expect('punctuation', '.'); expect('punctuation', '.');
        rest = true;
      }
      const nameTok      = expect('identifier');
      const typeAnnotation = check('punctuation', ':') ? (advance(), parseTypeAnnotation()) : null;
      const defaultValue   = check('operator', '=') ? (advance(), parseExpression()) : null;
      params.push({
        name: nameTok.value, typeAnnotation, defaultValue, rest,
        line: nameTok.line, col: nameTok.col,
      });
      if (!check('punctuation', ')')) expect('punctuation', ',');
      if (rest) break;
    }
    expect('punctuation', ')');
    return params;
  }

  /**
   * 型名をパースする
   * 有効な型: number | string | boolean | flow | any
   * 型名は identifier トークンとして来る（キーワードではない）
   */
  function parseTypeAnnotation() {
    const VALID_TYPES = new Set(['number', 'string', 'boolean', 'flow', 'any']);
    const t = peek();
    if (t.type !== 'identifier' || !VALID_TYPES.has(t.value)) {
      throw new SyntaxError(
        `型名が無効です: "${t.value}" (有効: ${[...VALID_TYPES].join(' | ')}) at pos ${t.pos}`
      );
    }
    advance();
    return t.value;   // 型名を文字列で返す
  }

  function parseBlock() {
    expect('punctuation', '{');
    const body = [];
    while (!check('punctuation', '}')) body.push(parseStatement());
    expect('punctuation', '}');
    return body;
  }

  function parseReturnStmt() {
    expect('keyword', 'return');
    const value = (!check('punctuation', '}') && !isEof()) ? parseExpression() : null;
    return { type: 'ReturnStmt', value };
  }

  /**
   * try { ... } catch (e) { ... }
   *
   * AST:
   * {
   *   type:     'TryCatchStmt',
   *   tryBody:  [...stmts],
   *   catchVar: 'e',          // catch 変数名
   *   catchBody:[...stmts],
   * }
   */
  function parseTryCatch() {
    expect('keyword', 'try');
    const tryBody = parseBlock();

    expect('keyword', 'catch');
    expect('punctuation', '(');
    const catchVar = expect('identifier').value;   // catch (e) の変数名
    expect('punctuation', ')');
    const catchBody = parseBlock();

    return { type: 'TryCatchStmt', tryBody, catchVar, catchBody };
  }

  /**
   * throw expression
   *
   * AST:
   * { type: 'ThrowStmt', value: <expr> }
   */
  function parseThrow() {
    expect('keyword', 'throw');
    // 次が } や EOF なら値なし throw（稀だが構文エラーにしない）
    const value = (!check('punctuation', '}') && !isEof())
      ? parseExpression()
      : null;
    return { type: 'ThrowStmt', value };
  }

  /**
   * if / else if / else
   *
   * AST:
   * {
   *   type:       'IfStmt',
   *   condition:  <expr>,
   *   thenBody:   [...stmts],
   *   elseBody:   [...stmts] | null   // else if は再帰的な IfStmt になる
   * }
   */
  function parseIfStmt() {
    expect('keyword', 'if');
    expect('punctuation', '(');
    const condition = parseExpression();
    expect('punctuation', ')');
    const thenBody = parseBlock();

    // else / else if（省略可能）
    let elseBody = null;
    if (check('keyword', 'else')) {
      advance();
      if (check('keyword', 'if')) {
        // else if → 再帰的に IfStmt ノードとして elseBody に格納
        elseBody = [parseIfStmt()];
      } else {
        elseBody = parseBlock();
      }
    }

    return { type: 'IfStmt', condition, thenBody, elseBody };
  }

  /**
   * while (condition) { body }
   *
   * AST: { type: 'WhileStmt', condition: <expr>, body: [...stmts] }
   */
  function parseWhileStmt() {
    expect('keyword', 'while');
    expect('punctuation', '(');
    const condition = parseExpression();
    expect('punctuation', ')');
    const body = parseBlock();
    return { type: 'WhileStmt', condition, body };
  }

  // ── 式（演算子優先順位: 低 → 高）────────────────────────────
  //
  //  parseExpression
  //    └─ parseAssignment     ( x = expr  再代入 )
  //         └─ parseLogicalOr      ( || )
  //              └─ parseLogicalAnd ( && )
  //                   └─ parseEquality   ( ==, != )
  //                        └─ parseRelational ( <, >, <=, >= )
  //                             └─ parseAdditive ( +, - )
  //                                  └─ parseMultiplicative ( *, / )
  //                                       └─ parseUnary ( ! )
  //                                            └─ parseCallOrMember
  //                                                 └─ parsePrimary

  const parseExpression = () => parseAssignment();

  /**
   * 再代入: x = expr  または  arr[i] = expr
   * 左辺が Identifier か IndexExpr のときだけ代入として扱う
   * それ以外は通常の式として素通し
   */
  function parseAssignment() {
    const left = parseLogicalOr();

    if (check('operator', '=')) {
      advance();
      const value = parseAssignment();   // 右結合

      // 変数への再代入: x = expr
      if (left.type === 'Identifier') {
        return { type: 'AssignStmt', name: left.name, value };
      }
      // インデックス代入: arr[i] = expr
      if (left.type === 'IndexExpr') {
        return { type: 'IndexAssignStmt', object: left.object, index: left.index, value };
      }
      throw new SyntaxError('代入の左辺が無効です（変数か配列インデックスのみ許可）');
    }

    return left;
  }

  function parseLogicalOr() {
    let left = parseLogicalAnd();
    while (check('operator', '||')) {
      const op = advance().value;
      left = { type: 'BinaryExpr', op, left, right: parseLogicalAnd() };
    }
    return left;
  }

  function parseLogicalAnd() {
    let left = parseEquality();
    while (check('operator', '&&')) {
      const op = advance().value;
      left = { type: 'BinaryExpr', op, left, right: parseEquality() };
    }
    return left;
  }

  function parseEquality() {
    let left = parseRelational();
    while (check('operator', '==') || check('operator', '!=')) {
      const op = advance().value;
      left = { type: 'BinaryExpr', op, left, right: parseRelational() };
    }
    return left;
  }

  function parseRelational() {
    let left = parseAdditive();
    while (
      check('operator', '<')  || check('operator', '>') ||
      check('operator', '<=') || check('operator', '>=')
    ) {
      const op = advance().value;
      left = { type: 'BinaryExpr', op, left, right: parseAdditive() };
    }
    return left;
  }

  function parseAdditive() {
    let left = parseMultiplicative();
    while (check('operator', '+') || check('operator', '-')) {
      const op = advance().value;
      left = { type: 'BinaryExpr', op, left, right: parseMultiplicative() };
    }
    return left;
  }

  function parseMultiplicative() {
    let left = parseUnary();
    while (check('operator', '*') || check('operator', '/')) {
      const op = advance().value;
      left = { type: 'BinaryExpr', op, left, right: parseUnary() };
    }
    return left;
  }

  /**
   * 単項演算子: !expr / -expr
   * AST: { type: 'UnaryExpr', op: '!' | '-', operand: <expr> }
   */
  function parseUnary() {
    if (check('operator', '!') || check('operator', '-')) {
      const op = advance().value;
      return { type: 'UnaryExpr', op, operand: parseUnary() };
    }
    return parseCallOrMember();
  }

  function parseCallOrMember() {
    let node = parsePrimary();
    while (true) {
      if (check('punctuation', '.')) {
        const dot = advance();
        const prop = expect('identifier');
        node = { type: 'MemberExpr', object: node, property: prop.value,
                 line: prop.line, col: prop.col };
      } else if (check('punctuation', '(')) {
        const lp = peek();
        node = { type: 'CallExpr', callee: node, args: parseArgList(),
                 line: node.line, col: node.col };
      } else if (check('punctuation', '[')) {
        advance();
        const index = parseExpression();
        expect('punctuation', ']');
        node = { type: 'IndexExpr', object: node, index,
                 line: node.line, col: node.col };
      } else {
        break;
      }
    }
    return node;
  }

  function parseArgList() {
    expect('punctuation', '(');
    const args = [];
    while (!check('punctuation', ')')) {
      args.push(parseExpression());
      if (!check('punctuation', ')')) expect('punctuation', ',');
    }
    expect('punctuation', ')');
    return args;
  }

  function parsePrimary() {
    const t = peek();
    if (t.type === 'number')     { advance(); return { type: 'NumberLiteral',  value: t.value }; }
    if (t.type === 'string')     { advance(); return { type: 'StringLiteral',  value: t.value }; }
    if (t.type === 'identifier') {
      advance();
      return { type: 'Identifier', name: t.value, line: t.line, col: t.col };
    }
    if (t.type === 'keyword' && t.value === 'fn') return parseFunctionDecl();

    // boolean / null リテラル
    if (t.type === 'keyword' && t.value === 'true')  { advance(); return { type: 'BoolLiteral',  value: true  }; }
    if (t.type === 'keyword' && t.value === 'false') { advance(); return { type: 'BoolLiteral',  value: false }; }
    if (t.type === 'keyword' && t.value === 'null')  { advance(); return { type: 'NullLiteral',  value: null  }; }

    // テンプレートリテラル: `hello ${name} world`
    if (t.type === 'template') {
      advance();
      return parseTemplateLiteral(t.value);
    }

    // 配列リテラル: [1, 2, 3]
    if (t.type === 'punctuation' && t.value === '[') {
      advance();
      const elements = [];
      while (!check('punctuation', ']')) {
        elements.push(parseExpression());
        if (!check('punctuation', ']')) expect('punctuation', ',');
      }
      expect('punctuation', ']');
      return { type: 'ArrayLiteral', elements };
    }

    // オブジェクトリテラル: { key: value, ... }
    // ※ { の直後に識別子/文字列 + : が来た場合のみオブジェクトとして解釈
    if (t.type === 'punctuation' && t.value === '{') {
      return parseObjectLiteral();
    }

    if (t.type === 'punctuation' && t.value === '(') {
      advance();
      const expr = parseExpression();
      expect('punctuation', ')');
      return expr;
    }
    throw new SyntaxError(`${t.line}:${t.col}: 予期しないトークン "${t.value}"`);
  }

  /**
   * オブジェクトリテラル: { name: "ae", version: 1 }
   * キーは識別子または文字列
   * AST: { type: 'ObjectLiteral', properties: [{ key, value }] }
   */
  function parseObjectLiteral() {
    expect('punctuation', '{');
    const properties = [];
    while (!check('punctuation', '}')) {
      // スプレッド: { ...obj, key: val }
      if (check('punctuation', '.')) {
        expect('punctuation', '.'); expect('punctuation', '.'); expect('punctuation', '.');
        const expr = parseExpression();
        properties.push({ spread: true, value: expr });
        if (!check('punctuation', '}')) expect('punctuation', ',');
        continue;
      }

      const kt = peek();
      let key;
      if (kt.type === 'identifier' || kt.type === 'string') {
        key = advance().value;
      } else if (kt.type === 'keyword') {
        key = advance().value;
      } else {
        throw new SyntaxError(`${kt.line}:${kt.col}: オブジェクトキーには識別子または文字列が必要です`);
      }
      expect('punctuation', ':');
      const value = parseExpression();
      properties.push({ key, value });
      if (!check('punctuation', '}')) expect('punctuation', ',');
    }
    expect('punctuation', '}');
    return { type: 'ObjectLiteral', properties };
  }

  /**
   * テンプレートリテラルをパースして TemplateLiteral ノードを返す
   * `hello ${name}, you are ${age} years old`
   * → parts: ['hello ', expr(name), ', you are ', expr(age), ' years old']
   *
   * @param {string} raw - バッククォート内の生テキスト
   * AST: { type: 'TemplateLiteral', parts: [string | ASTNode] }
   */
  function parseTemplateLiteral(raw) {
    const parts = [];
    let text = '';
    let i = 0;
    while (i < raw.length) {
      if (raw[i] === '$' && raw[i+1] === '{') {
        if (text) { parts.push({ type: 'StringLiteral', value: text }); text = ''; }
        i += 2; // ${ を消費
        // } まで式を取り出す（ネスト対応: 深さカウント）
        let depth = 1, exprSrc = '';
        while (i < raw.length && depth > 0) {
          if      (raw[i] === '{') depth++;
          else if (raw[i] === '}') { depth--; if (depth === 0) { i++; break; } }
          exprSrc += raw[i++];
        }
        // 式を再帰パース
        const exprTokens = tokenize(exprSrc);
        parts.push(parse(exprTokens).body[0]);
      } else {
        text += raw[i++];
      }
    }
    if (text) parts.push({ type: 'StringLiteral', value: text });
    return { type: 'TemplateLiteral', parts };
  }

  return parseProgram();
}

/**
 * ソースコード文字列 → AST
 */
function parseAetherScript(src) {
  return parse(tokenize(src));
}

module.exports = { tokenize, parse, parseAetherScript };
