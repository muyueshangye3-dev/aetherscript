/**
 * AetherScript テストランナー
 *
 * 使い方:
 *   node test_runner.js          全テスト実行
 *   node test_runner.js --fast   失敗したら即停止
 *
 * テストを追加するには tests 配列に追記するだけ。
 */

'use strict';

const { parseAetherScript } = require('./parser');
const { run }               = require('./interpreter');

// ─── テストヘルパー ────────────────────────────────────────────────

let passed = 0, failed = 0, total = 0;
const failures = [];
const fastFail = process.argv.includes('--fast');

/**
 * 1テストケースを実行する
 * @param {string}   label    - テスト名
 * @param {string}   src      - AetherScript ソースコード
 * @param {string[]} expected - print() の出力を行単位で指定
 */
async function test(label, src, expected) {
  total++;
  const output = [];

  // print をキャプチャする env を作って実行
  try {
    const { evalNode, createGlobalEnv } = require('./interpreter');
    const env = createGlobalEnv();
    env.print = (...args) => output.push(args.map(String).join(' '));

    const ast = parseAetherScript(src);
    await evalNode({ type: 'Program', body: ast.body }, env);
  } catch (e) {
    const msg = `[例外] ${e.message}`;
    const ok  = expected.length === 1 && expected[0].startsWith('[例外]') &&
                msg.includes(expected[0].slice(5).trim());
    if (ok) {
      passed++;
      process.stdout.write(`  \x1b[32m✓\x1b[0m ${label}\n`);
      return;
    }
    failed++;
    failures.push({ label, expected, actual: [msg] });
    process.stdout.write(`  \x1b[31m✗\x1b[0m ${label}\n`);
    process.stdout.write(`    期待: ${JSON.stringify(expected)}\n`);
    process.stdout.write(`    実際: ${JSON.stringify([msg])}\n`);
    if (fastFail) process.exit(1);
    return;
  }

  const actual = output;
  const ok = expected.length === actual.length &&
             expected.every((e, i) => e === actual[i]);

  if (ok) {
    passed++;
    process.stdout.write(`  \x1b[32m✓\x1b[0m ${label}\n`);
  } else {
    failed++;
    failures.push({ label, expected, actual });
    process.stdout.write(`  \x1b[31m✗\x1b[0m ${label}\n`);
    process.stdout.write(`    期待: ${JSON.stringify(expected)}\n`);
    process.stdout.write(`    実際: ${JSON.stringify(actual)}\n`);
    if (fastFail) process.exit(1);
  }
}

function section(name) {
  process.stdout.write(`\n\x1b[1m${name}\x1b[0m\n`);
}

// ─── テストケース定義 ──────────────────────────────────────────────

async function main() {
  console.log('\nAetherScript テストスイート\n');

  // ── 基本リテラル・変数 ───────────────────────────────────────────
  section('リテラル・変数');
  await test('数値リテラル',   'print(42)',             ['42']);
  await test('文字列リテラル', 'print("hello")',        ['hello']);
  await test('true',           'print(true)',           ['true']);
  await test('false',          'print(false)',          ['false']);
  await test('null',           'print(null)',           ['null']);
  await test('let 宣言',       'let x = 10\nprint(x)', ['10']);
  await test('再代入',         'let x = 1\nx = 99\nprint(x)', ['99']);

  // ── 演算子 ───────────────────────────────────────────────────────
  section('演算子');
  await test('四則演算',   'print(2 + 3 * 4)', ['14']);
  await test('比較 ==',    'print(1 == 1)',    ['true']);
  await test('比較 !=',    'print(1 != 2)',    ['true']);
  await test('比較 <',     'print(3 < 5)',     ['true']);
  await test('比較 >=',    'print(5 >= 5)',    ['true']);
  await test('論理 &&',    'print(true && false)', ['false']);
  await test('論理 ||',    'print(false || true)', ['true']);
  await test('単項 !',     'print(!false)',    ['true']);
  await test('単項 -',     'let x = 5\nprint(-x + 10)', ['5']);
  await test('+=',         'let x = 10\nx += 5\nprint(x)',  ['15']);
  await test('-=',         'let x = 10\nx -= 3\nprint(x)',  ['7']);
  await test('*=',         'let x = 4\nx *= 3\nprint(x)',   ['12']);
  await test('/=',         'let x = 12\nx /= 4\nprint(x)',  ['3']);
  await test('++',         'let i = 0\ni++\ni++\nprint(i)', ['2']);
  await test('--',         'let i = 3\ni--\nprint(i)',       ['2']);
  await test('短絡 &&',    'let x = 0\nif (false && x) { print("no") } else { print("ok") }', ['ok']);
  await test('短絡 ||',    'if (true || false) { print("ok") }', ['ok']);

  // ── 制御フロー ──────────────────────────────────────────────────
  section('制御フロー');
  await test('if true',   'if (1 == 1) { print("yes") }', ['yes']);
  await test('if false',  'if (1 == 2) { print("no") } else { print("ok") }', ['ok']);
  await test('else if',   `
let x = 2
if (x == 1) { print("one") }
else if (x == 2) { print("two") }
else { print("other") }`, ['two']);
  await test('while',     'let i = 0\nlet s = 0\nwhile (i < 5) { s += i\ni++ }\nprint(s)', ['10']);
  await test('for C',     'let s = 0\nfor (let i = 1; i <= 5; i++) { s += i }\nprint(s)', ['15']);
  await test('for...of 配列', `
let arr = [10, 20, 30]
let s = 0
for (let x of arr) { s += x }
print(s)`, ['60']);
  await test('for...of 文字列', `
let s = ""
for (let c of "abc") { s = s + c + "-" }
print(s)`, ['a-b-c-']);
  await test('break',     'let i = 0\nwhile (true) { if (i == 3) { break }\ni++ }\nprint(i)', ['3']);
  await test('continue',  `
let s = 0
for (let i = 1; i <= 5; i++) {
  if (i == 3) { continue }
  s += i
}
print(s)`, ['12']);
  await test('switch',    `
switch (2) {
  case 1: print("one") break
  case 2: print("two") break
  default: print("other")
}`, ['two']);
  await test('switch default', `
switch (99) {
  case 1: print("one") break
  default: print("default")
}`, ['default']);

  // ── 関数 ────────────────────────────────────────────────────────
  section('関数');
  await test('基本関数',     'fn add(a,b) { return a+b }\nprint(add(3,4))', ['7']);
  await test('再帰',         'fn fact(n) { if (n<=1) { return 1 } return n * fact(n-1) }\nprint(fact(5))', ['120']);
  await test('無名関数',     'let f = fn(x) { return x * 2 }\nprint(f(7))', ['14']);
  await test('デフォルト引数', `
fn greet(name, prefix) {
  if (prefix == null) { prefix = "Hello" }
  return prefix
}
print(greet("Alice", null))
print(greet("Bob", "Hi"))`, ['Hello', 'Hi']);
  await test('クロージャ',   `
fn makeCounter() {
  let count = 0
  return fn() { count += 1\nreturn count }
}
let c = makeCounter()
print(c())
print(c())
print(c())`, ['1', '2', '3']);

  // ── 配列 ────────────────────────────────────────────────────────
  section('配列');
  await test('配列リテラル',  'let a = [1,2,3]\nprint(a[0])\nprint(a[2])', ['1','3']);
  await test('配列 インデックス代入', `
import array
let a = [1,2,3]
array.set(a, 1, 99)
print(a[1])`, ['99']);
  await test('配列分割代入',  'let [x, y, z] = [10, 20, 30]\nprint(x)\nprint(z)', ['10','30']);
  await test('array.push',    'import array\nlet a = []\narray.push(a,1)\narray.push(a,2)\nprint(array.length(a))', ['2']);
  await test('array.range',   'import array\nlet r = array.range(1,4)\nfor (let x of r) { print(x) }', ['1','2','3']);
  await test('array.join',    'import array\nprint(array.join([1,2,3], "-"))', ['1-2-3']);

  // ── オブジェクト ────────────────────────────────────────────────
  section('オブジェクト');
  await test('オブジェクトリテラル', 'let o = { x: 1, y: 2 }\nprint(o.x)\nprint(o.y)', ['1','2']);
  await test('ネスト',              'let o = { a: { b: 42 } }\nprint(o.a.b)', ['42']);
  await test('スプレッド',          'let a = { x: 1 }\nlet b = { ...a, y: 2 }\nprint(b.x)\nprint(b.y)', ['1','2']);
  await test('スプレッドで上書き',  'let a = { x: 1, y: 2 }\nlet b = { ...a, x: 99 }\nprint(b.x)', ['99']);

  // ── 例外処理 ────────────────────────────────────────────────────
  section('例外処理');
  await test('throw/catch',  'try { throw "boom" } catch (e) { print(e) }', ['boom']);
  await test('ネスト catch', `
try {
  try { throw "inner" }
  catch (e) { throw "outer" }
} catch (e) { print(e) }`, ['outer']);
  await test('catch 内 return', `
fn safe() {
  try { throw "err" }
  catch (e) { return e }
}
print(safe())`, ['err']);
  await test('エラーなし skip', `
try { let x = 1 }
catch (e) { print("should not") }
print("ok")`, ['ok']);

  // ── 型システム ──────────────────────────────────────────────────
  section('型システム');
  await test('number OK',   'let x: number = 42\nprint(x)', ['42']);
  await test('string OK',   'let s: string = "hi"\nprint(s)', ['hi']);
  await test('型不一致 var', `
try { let x: number = "bad" }
catch(e) { print("caught") }`, ['caught']);
  await test('型不一致 arg', `
fn f(x: number) { return x }
try { f("bad") }
catch(e) { print("caught") }`, ['caught']);
  await test('any 型',      'fn f(x: any) { return x }\nprint(f(1))\nprint(f("a"))', ['1','a']);

  // ── テンプレートリテラル ─────────────────────────────────────────
  section('テンプレートリテラル');
  await test('基本',        'let n = "World"\nprint(`Hello ${n}!`)', ['Hello World!']);
  await test('数値埋め込み','let x = 42\nprint(`x = ${x}`)', ['x = 42']);
  await test('式埋め込み',  'let a = 3\nlet b = 4\nprint(`${a} + ${b} = ${a + b}`)', ['3 + 4 = 7']);

  // ── 標準ライブラリ ───────────────────────────────────────────────
  section('標準ライブラリ');
  await test('math.sqrt',   'import "@math"\nprint(math.sqrt(16))', ['4']);
  await test('math.floor',  'import "@math"\nprint(math.floor(3.7))', ['3']);
  await test('string.upper','import string\nprint(string.upper("hello"))', ['HELLO']);
  await test('string.includes','import string\nprint(string.includes("foobar","bar"))', ['true']);
  await test('core.type 数値','import core\nprint(core.type(42))', ['number']);
  await test('core.type 文字列','import core\nprint(core.type("hi"))', ['string']);
  await test('fs read/write', `
import fs
fs.write("/tmp/ae_test.txt", "hello ae")
let content = fs.read("/tmp/ae_test.txt")
print(content)
fs.remove("/tmp/ae_test.txt")`, ['hello ae']);

  // ── Flow ─────────────────────────────────────────────────────────
  section('Flow');
  // Flow の非同期 emit は setImmediate 後に発火するため
  // テストランナーの同期 await では捕捉が難しい。
  // 統合テスト (flow_sample.ae) で動作確認済み。
  // await test('Flow map + subscribe', ...)  ← 省略

  // ─── 結果表示 ─────────────────────────────────────────────────────
  const color = failed === 0 ? '\x1b[32m' : '\x1b[31m';
  console.log(`\n${color}${'─'.repeat(40)}\x1b[0m`);
  console.log(`${color}結果: ${passed}/${total} 通過  ${failed > 0 ? `(${failed} 失敗)` : ''}\x1b[0m`);
  if (failures.length > 0) {
    console.log('\n失敗したテスト:');
    failures.forEach(f => console.log(`  - ${f.label}`));
  }
  process.exit(failed > 0 ? 1 : 0);
}

main().catch(e => { console.error(e); process.exit(1); });
