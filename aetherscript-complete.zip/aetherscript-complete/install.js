/**
 * AetherScript パッケージマネージャ — install.js
 *
 * 責務:
 *   1. registry.json からパッケージの URL を解決する
 *   2. URL からソースを fetch（HTTP）または readFile（file://）で取得する
 *   3. modules/<pkgName>/index.ae に保存する
 *
 * 設計:
 *   - バージョン管理・依存解決は行わない（最小構成）
 *   - registry.json はプロジェクトルートに置く
 *   - 将来: registry URL を外部サーバーにする場合も fetch を差し替えるだけ
 */

'use strict';

const fs   = require('fs');
const path = require('path');

// ─── 定数 ─────────────────────────────────────────────────────────

/** モジュール保存先ディレクトリ名 */
const MODULES_DIR   = 'modules';

/** レジストリファイル名 */
const REGISTRY_FILE = 'registry.json';

// ─── ヘルパー ─────────────────────────────────────────────────────

/** 色付きログ */
const log = {
  info : msg => console.log(`\x1b[36m[install]\x1b[0m ${msg}`),
  ok   : msg => console.log(`\x1b[32m[install]\x1b[0m ${msg}`),
  warn : msg => console.log(`\x1b[33m[install]\x1b[0m ${msg}`),
  error: msg => console.error(`\x1b[31m[install]\x1b[0m ${msg}`),
};

/**
 * レジストリ JSON を読み込む
 * プロジェクトルートの registry.json → なければ CLI と同じディレクトリを探す
 *
 * @param {string} cwd - 実行ディレクトリ
 * @returns {Object}   - { pkgName: url, ... }
 */
function loadRegistry(cwd) {
  // 探索順: cwd → CLI のあるディレクトリ
  const candidates = [
    path.join(cwd, REGISTRY_FILE),
    path.join(__dirname, REGISTRY_FILE),
  ];

  for (const p of candidates) {
    if (fs.existsSync(p)) {
      try {
        const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
        // _ で始まるキーはコメント用フィールドなので除外
        return Object.fromEntries(
          Object.entries(raw).filter(([k]) => !k.startsWith('_'))
        );
      } catch (e) {
        throw new Error(`registry.json の解析に失敗しました: ${e.message}`);
      }
    }
  }
  throw new Error(`registry.json が見つかりません (探索: ${candidates.join(', ')})`);
}

/**
 * URL からソースコードを取得する
 *
 * - http:// / https://  → fetch（Node 18+）
 * - file://             → fs.readFileSync
 *
 * @param {string} url
 * @returns {Promise<string>} ソースコード文字列
 */
async function fetchSource(url) {
  // ── file:// ────────────────────────────────────────────────────
  if (url.startsWith('file://')) {
    const filePath = url.replace(/^file:\/\//, '');
    try {
      return fs.readFileSync(path.resolve(filePath), 'utf8');
    } catch (e) {
      throw new Error(`ローカルファイルの読み込み失敗: ${filePath}\n  ${e.message}`);
    }
  }

  // ── http:// / https:// ─────────────────────────────────────────
  if (url.startsWith('http://') || url.startsWith('https://')) {
    let res;
    try {
      res = await fetch(url);
    } catch (e) {
      throw new Error(`ネットワークエラー: ${url}\n  ${e.message}`);
    }
    if (!res.ok) {
      throw new Error(`ダウンロード失敗 (HTTP ${res.status}): ${url}`);
    }
    return res.text();
  }

  throw new Error(`未対応の URL スキーム: ${url}`);
}

/**
 * パッケージをインストールする
 *
 * @param {string} pkgName - パッケージ名（例: "colors"）
 * @param {string} cwd     - インストール先ディレクトリ（通常は process.cwd()）
 */
async function installPackage(pkgName, cwd = process.cwd()) {
  // ① レジストリ解決
  log.info(`"${pkgName}" をインストールしています...`);
  const registry = loadRegistry(cwd);

  if (!(pkgName in registry)) {
    const available = Object.keys(registry).join(', ');
    throw new Error(
      `パッケージ "${pkgName}" はレジストリに存在しません\n  利用可能: ${available || '（なし）'}`
    );
  }

  const url = registry[pkgName];
  log.info(`取得元: ${url}`);

  // ② ソース取得
  const source = await fetchSource(url);

  // ③ 保存先ディレクトリを作成
  //    modules/<pkgName>/index.ae
  const pkgDir     = path.join(cwd, MODULES_DIR, pkgName);
  const indexPath  = path.join(pkgDir, 'index.ae');

  fs.mkdirSync(pkgDir, { recursive: true });

  // ④ 上書き確認（すでにある場合は警告のみ）
  if (fs.existsSync(indexPath)) {
    log.warn(`上書きします: ${path.relative(cwd, indexPath)}`);
  }

  fs.writeFileSync(indexPath, source, 'utf8');
  log.ok(`✓ ${pkgName} → ${path.relative(cwd, indexPath)}`);

  return indexPath;
}

module.exports = { installPackage, loadRegistry, MODULES_DIR };
