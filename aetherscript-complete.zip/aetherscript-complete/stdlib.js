/**
 * AetherScript 標準ライブラリ
 *
 * 各モジュールは { 関数名: JS関数 } の plain object として定義する。
 * ModuleLoader の _nativeModules に登録することで
 * AetherScript 側から `import fs` のように使える。
 */

'use strict';

const nodeFs   = require('fs');
const nodePath = require('path');

// ─── core ─────────────────────────────────────────────────────────
// 基本ユーティリティ

const core = {
  /**
   * 値の型名を返す
   * AetherScript の型: "number" | "string" | "boolean" | "flow" | "function" | "null" | "object"
   */
  type(value) {
    if (value === null || value === undefined) return 'null';
    // Flow インスタンスかどうかは duck-typing で判定
    if (typeof value === 'object' && typeof value.subscribe === 'function' && typeof value.emit === 'function') {
      return 'flow';
    }
    return typeof value; // "number" | "string" | "boolean" | "function" | "object"
  },

  /** 値をそのまま返す（パイプライン・テスト用） */
  identity(value) {
    return value;
  },

  /** 数値に変換する */
  toNumber(value) {
    const n = Number(value);
    if (isNaN(n)) throw new TypeError(`toNumber: "${value}" は数値に変換できません`);
    return n;
  },

  /** 文字列に変換する */
  toString(value) {
    if (value === null || value === undefined) return 'null';
    return String(value);
  },
};

// ─── math ─────────────────────────────────────────────────────────
// 数学関数

const math = {
  abs(x)        { return Math.abs(x); },
  floor(x)      { return Math.floor(x); },
  ceil(x)       { return Math.ceil(x); },
  round(x)      { return Math.round(x); },
  sqrt(x)       { return Math.sqrt(x); },
  pow(base, exp){ return Math.pow(base, exp); },
  max(a, b)     { return Math.max(a, b); },
  min(a, b)     { return Math.min(a, b); },
  /** 0以上1未満の乱数 */
  random()      { return Math.random(); },
  /** min〜max の整数乱数 */
  randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },
  PI: Math.PI,
};

// ─── string ───────────────────────────────────────────────────────
// 文字列操作

const string = {
  /** 文字列の長さ */
  length(s)            { return String(s).length; },
  /** 大文字変換 */
  upper(s)             { return String(s).toUpperCase(); },
  /** 小文字変換 */
  lower(s)             { return String(s).toLowerCase(); },
  /** 前後の空白を除去 */
  trim(s)              { return String(s).trim(); },
  /** 部分文字列 */
  slice(s, start, end) { return String(s).slice(start, end); },
  /** 文字列を区切り文字で分割（配列ではなく最初の要素を返す簡易版） */
  split(s, sep)        { return String(s).split(sep); },
  /** 含まれるか */
  includes(s, sub)     { return String(s).includes(sub); },
  /** 置換 */
  replace(s, from, to) { return String(s).replace(from, to); },
  /** 繰り返し */
  repeat(s, n)         { return String(s).repeat(n); },
  /** 文字列結合 */
  concat(a, b)         { return String(a) + String(b); },
};

// ─── time ─────────────────────────────────────────────────────────
// 時刻・待機

const time = {
  /** Unix タイムスタンプ（ミリ秒） */
  now() {
    return Date.now();
  },

  /**
   * 非同期 sleep — Promise を返す
   * evalNode が await するため、AetherScript 側では通常の呼び出しに見える
   * 例: time.sleep(1000)  → 1秒待機してから次の文へ
   * @param {number} ms - 待機ミリ秒
   * @returns {Promise<void>}
   */
  sleep(ms) {
    if (typeof ms !== 'number' || ms < 0) {
      throw new TypeError(`sleep: 正の数値を指定してください (got ${ms})`);
    }
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  /**
   * 現在の日時を読みやすい文字列で返す
   * 例: "2025-03-19 14:30:00"
   */
  format(ts) {
    const d = new Date(ts !== undefined ? ts : Date.now());
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ` +
           `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  },
};

// ─── fs ───────────────────────────────────────────────────────────
// ファイルシステム

const fsModule = {
  /**
   * ファイルを読み込む（UTF-8）
   * @param {string} filePath
   * @returns {string}
   */
  read(filePath) {
    if (typeof filePath !== 'string') throw new TypeError('fs.read: パスは文字列で指定してください');
    try {
      return nodeFs.readFileSync(filePath, 'utf8');
    } catch (e) {
      if (e.code === 'ENOENT') throw new Error(`fs.read: ファイルが見つかりません: ${filePath}`);
      throw new Error(`fs.read: 読み込み失敗: ${e.message}`);
    }
  },

  /**
   * ファイルに書き込む（UTF-8）
   * @param {string} filePath
   * @param {string} content
   */
  write(filePath, content) {
    if (typeof filePath !== 'string') throw new TypeError('fs.write: パスは文字列で指定してください');
    try {
      nodeFs.writeFileSync(filePath, String(content), 'utf8');
    } catch (e) {
      throw new Error(`fs.write: 書き込み失敗: ${e.message}`);
    }
  },

  /**
   * ファイルが存在するか確認する
   * @param {string} filePath
   * @returns {boolean}
   */
  exists(filePath) {
    return nodeFs.existsSync(filePath);
  },

  /**
   * ファイルを削除する
   * @param {string} filePath
   */
  remove(filePath) {
    try {
      nodeFs.unlinkSync(filePath);
    } catch (e) {
      throw new Error(`fs.remove: 削除失敗: ${e.message}`);
    }
  },
};

const { httpModule } = require('./http');

// ─── array ────────────────────────────────────────────────────────
// 配列ユーティリティ（JS Array のラッパー）

const arrayModule = {
  /** 末尾に要素を追加（破壊的）*/
  push(arr, val)         { arr.push(val); return arr; },
  /** 末尾から要素を取り出す */
  pop(arr)               { return arr.pop(); },
  /** 先頭に要素を追加（破壊的）*/
  unshift(arr, val)      { arr.unshift(val); return arr; },
  /** 先頭から要素を取り出す */
  shift(arr)             { return arr.shift(); },
  /** 長さ */
  length(arr)            { return arr.length; },
  /** インデックスで取得 */
  get(arr, i)            { return arr[i]; },
  /** インデックスに値をセット（破壊的）*/
  set(arr, i, val)       { arr[i] = val; return arr; },
  /** スライス（非破壊） */
  slice(arr, s, e)       { return arr.slice(s, e); },
  /** 含まれるか */
  includes(arr, val)     { return arr.includes(val); },
  /** 結合して文字列に */
  join(arr, sep = ',')   { return arr.join(sep); },
  /** 逆順（非破壊） */
  reverse(arr)           { return [...arr].reverse(); },
  /** 空配列を作る */
  empty()                { return []; },
  /** 範囲配列: range(3) → [0,1,2]、range(1,4) → [1,2,3] */
  range(start, end) {
    if (end === undefined) { end = start; start = 0; }
    const result = [];
    for (let i = start; i < end; i++) result.push(i);
    return result;
  },
};

// ─── エクスポート ──────────────────────────────────────────────────

/**
 * モジュール名 → エクスポートオブジェクト のマップ
 * ModuleLoader はこのマップをネイティブモジュールとして参照する
 */
const STDLIB = new Map([
  ['core',   core],
  ['math',   math],
  ['string', string],
  ['time',   time],
  ['fs',     fsModule],
  ['http',   httpModule],
  ['array',  arrayModule],   // ← 追加
]);

module.exports = { STDLIB };
