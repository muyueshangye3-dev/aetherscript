/**
 * AetherScript Flow Engine
 */

class Flow {
  constructor() {
    this.subscribers = new Map();
    this._nextId = 0;
    this._cleanupFns = [];
    this._stopped = false;
  }

  emit(value) {
    if (this._stopped) return;
    for (const [id, fn] of this.subscribers) {
      try { fn(value); }
      catch (err) { console.error(`[Flow] subscriber(id=${id}) error:`, err.message); }
    }
  }

  subscribe(fn) {
    if (this._stopped) return () => {};
    const id = this._nextId++;
    this.subscribers.set(id, fn);
    return () => {
      this.subscribers.delete(id);
      if (this.subscribers.size === 0) this._cleanup();
    };
  }

  _cleanup() {
    if (this._stopped) return;
    this._stopped = true;
    for (const fn of this._cleanupFns) {
      try { fn(); } catch (err) { console.error('[Flow] cleanup error:', err.message); }
    }
    this._cleanupFns = [];
    this.subscribers.clear();
  }

  _addCleanup(fn) { this._cleanupFns.push(fn); }

  map(fn) {
    const next = new Flow();
    const unsub = this.subscribe(v => next.emit(fn(v)));
    next._addCleanup(unsub);
    return next;
  }

  scan(fn, initial) {
    const next = new Flow();
    let state = initial;
    let hasState = initial !== undefined;
    const unsub = this.subscribe(value => {
      if (!hasState) { state = value; hasState = true; next.emit(state); return; }
      state = fn(state, value);
      next.emit(state);
    });
    next._addCleanup(unsub);
    return next;
  }

  filter(fn) {
    const next = new Flow();
    const unsub = this.subscribe(value => {
      try { if (fn(value)) next.emit(value); }
      catch (err) { console.error('[Flow] filter error:', err.message); }
    });
    next._addCleanup(unsub);
    return next;
  }
}

function interval(ms) {
  const flow = new Flow();
  const timer = setInterval(() => flow.emit(Date.now()), ms);
  flow._addCleanup(() => clearInterval(timer));
  return flow;
}

module.exports = { Flow, interval };
