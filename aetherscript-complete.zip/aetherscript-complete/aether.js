#!/usr/bin/env node
/**
 * AetherScript CLI
 *
 * ファイル構成:
 *   aether.js       ← このファイル（CLIエントリポイント）
 *   parser.js       ← Tokenizer + 再帰下降パーサー
 *   interpreter.js  ← ASTインタプリタ
 *   flow.js         ← Flowエンジン（interval / map / scan / filter）
 *   install.js      ← パッケージマネージャ
 *   registry.json   ← パッケージレジストリ
 *
 * 使い方:
 *   node aether.js run     <file.ae>
 *   node aether.js install <package>
 */

'use strict';

const fs                           = require('fs');
const path                         = require('path');
const { parseAetherScript }        = require('./parser');
const { run, formatError }         = require('./interpreter');
const { installPackage }           = require('./install');
const { startRepl }                = require('./repl');

// ─── ヘルパー ─────────────────────────────────────────────────────

/** エラーを赤字で表示して終了 */
function fatal(msg, detail) {
  console.error(`\x1b[31m[AetherScript Error]\x1b[0m ${msg}`);
  if (detail) console.error(`  ${detail}`);
  process.exit(1);
}

/** 使い方を表示 */
function printUsage() {
  console.log([
    '',
    '  \x1b[1mAetherScript CLI\x1b[0m',
    '',
    '  使い方:',
    '    node aether.js run     <file.ae>    ファイルを実行する',
    '    node aether.js repl                 対話モード（REPL）を起動する',
    '    node aether.js install <package>    パッケージをインストールする',
    '    node aether.js help                 使い方を表示する',
    '',
    '  例:',
    '    node aether.js run main.ae',
    '    node aether.js repl',
    '    node aether.js install colors',
    '',
  ].join('\n'));
}

// ─── サブコマンド ─────────────────────────────────────────────────

/**
 * run コマンド: .ae ファイルを読み込み → parse → 実行
 */
async function cmdRun(filePath) {
  if (!filePath) {
    fatal('ファイルパスを指定してください', '例: node aether.js run main.ae');
  }

  const absPath = path.resolve(filePath);

  // ① ファイル読み込み
  let src;
  try {
    src = fs.readFileSync(absPath, 'utf8');
  } catch (e) {
    if (e.code === 'ENOENT') fatal(`ファイルが見つかりません: ${filePath}`);
    fatal('ファイルの読み込みに失敗しました', e.message);
  }

  // ② パース
  let ast;
  try {
    ast = parseAetherScript(src);
  } catch (e) {
    // パーサーエラーは line:col がメッセージに含まれる
    console.error(`\x1b[31m[構文エラー]\x1b[0m ${filePath}`);
    console.error(`  ${e.message}`);
    // ソース該当行を表示
    if (e.message.match(/^(\d+):(\d+)/)) {
      const [, l, c] = e.message.match(/^(\d+):(\d+)/);
      const srcLines = src.split('\n');
      const srcLine  = srcLines[+l - 1] ?? '';
      const lineNum  = String(l).padStart(4);
      console.error(`${lineNum} \x1b[36m|\x1b[0m ${srcLine}`);
      console.error(`${' '.repeat(4 + 3 + (+c - 1))}\x1b[31m^\x1b[0m`);
    }
    process.exit(1);
  }

  // ③ 実行
  try {
    await run(ast, absPath);
  } catch (e) {
    console.error(formatError(e, filePath, src));
    process.exit(1);
  }
}

/**
 * install コマンド: レジストリからパッケージを取得して modules/ に保存
 *
 * 使い方: node aether.js install <pkgName> [pkgName2 ...]
 *
 * 複数パッケージを一度に指定可能:
 *   node aether.js install colors utils
 */
async function cmdInstall(pkgNames) {
  if (!pkgNames || pkgNames.length === 0) {
    fatal(
      'パッケージ名を指定してください',
      '例: node aether.js install colors'
    );
  }

  const cwd = process.cwd();
  let hasError = false;

  for (const pkgName of pkgNames) {
    try {
      await installPackage(pkgName, cwd);
    } catch (e) {
      console.error(`\x1b[31m[install error]\x1b[0m ${pkgName}: ${e.message}`);
      hasError = true;
    }
  }

  if (hasError) process.exit(1);
}

// ─── メイン ───────────────────────────────────────────────────────

async function main() {
  const [, , command, ...rest] = process.argv;

  switch (command) {
    case 'run':
      await cmdRun(rest[0]);
      break;

    case 'repl':
      await startRepl();
      break;

    case 'install':
      await cmdInstall(rest);        // rest = ["colors"] or ["colors", "utils"]
      break;

    case 'help':
    case '--help':
    case '-h':
    case undefined:
      printUsage();
      break;

    default:
      fatal(`不明なコマンド: ${command}`, '"node aether.js help" で使い方を確認できます');
  }
}

main().catch(err => {
  console.error('\x1b[31m[AetherScript 未捕捉エラー]\x1b[0m', err.message);
  process.exit(1);
});
