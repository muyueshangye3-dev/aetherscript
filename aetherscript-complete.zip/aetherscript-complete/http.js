/**
 * AetherScript 標準ライブラリ — http モジュール
 *
 * Node 18+ のグローバル fetch を使用する。
 * それ以前の環境では node:https フォールバックに切り替わる。
 *
 * 提供API:
 *   http.get(url, options?)     → Promise<any>
 *   http.post(url, body, opts?) → Promise<any>
 *   http.getFlow(url, opts?)    → Flow  （1回リクエスト → 値をemit）
 *   http.pollFlow(url, ms, opts?) → Flow（ms毎に繰り返しリクエスト）
 */

'use strict';

const { Flow } = require('./flow');

// ─── 内部ヘルパー ─────────────────────────────────────────────────

/**
 * Node 18+ の fetch を使ったリクエスト実行
 * @param {string} url
 * @param {RequestInit} options - fetch 互換オプション
 * @returns {Promise<{ status, headers, body, json? }>}
 */
async function _request(url, options = {}) {
  if (typeof url !== 'string' || !url.startsWith('http')) {
    throw new TypeError(`http: 有効なURLを指定してください (got "${url}")`);
  }

  let response;
  try {
    response = await fetch(url, options);
  } catch (e) {
    // ネットワーク到達不能・DNS失敗など
    throw new Error(`http: ネットワークエラー → ${e.message}`);
  }

  // レスポンスボディを取得
  const text = await response.text();

  // Content-Type が JSON なら自動パース
  const contentType = response.headers.get('content-type') || '';
  let body = text;
  if (contentType.includes('application/json')) {
    try { body = JSON.parse(text); }
    catch { /* パース失敗時はテキストのまま返す */ }
  }

  return {
    status:  response.status,
    ok:      response.ok,
    headers: Object.fromEntries(response.headers.entries()),
    body,
  };
}

// ─── 公開 API ─────────────────────────────────────────────────────

const httpModule = {

  /**
   * GET リクエスト
   * @param {string} url
   * @param {object} options - { headers: {…} } など
   * @returns {Promise<any>} レスポンスボディ（JSON なら自動パース済み）
   */
  async get(url, options = {}) {
    const res = await _request(url, { method: 'GET', ...options });
    if (!res.ok) throw new Error(`http.get: ${res.status} ${url}`);
    return res.body;
  },

  /**
   * POST リクエスト
   * @param {string} url
   * @param {any}    body    - 送信データ（object なら JSON シリアライズ）
   * @param {object} options - 追加オプション
   * @returns {Promise<any>}
   */
  async post(url, body, options = {}) {
    const isObj    = body !== null && typeof body === 'object';
    const bodyStr  = isObj ? JSON.stringify(body) : String(body);
    const headers  = {
      ...(isObj ? { 'Content-Type': 'application/json' } : {}),
      ...(options.headers || {}),
    };
    const res = await _request(url, {
      method: 'POST',
      body:   bodyStr,
      headers,
      ...options,
    });
    if (!res.ok) throw new Error(`http.post: ${res.status} ${url}`);
    return res.body;
  },

  /**
   * GET → Flow 変換（1回リクエスト・値を1度 emit して完了）
   *
   * 使用例（AetherScript）:
   *   flow data = http.getFlow("https://api.example.com/todos/1")
   *   data.subscribe(fn(v) { print(v) })
   *
   * emit を setImmediate で遅延することで、
   * FlowDecl の await 後に subscribe が確実に登録されてから値が届く。
   *
   * @param {string} url
   * @param {object} options
   * @returns {Flow}
   */
  getFlow(url, options = {}) {
    const flow = new Flow();
    httpModule.get(url, options)
      .then(body => {
        // setImmediate: 現在のイベントループフェーズを抜けてから emit
        // → subscribe(...) が先に呼ばれることを保証する
        setImmediate(() => flow.emit(body));
      })
      .catch(err => {
        console.error('[http.getFlow] エラー:', err.message);
        setImmediate(() => flow._cleanup());
      });
    return flow;
  },

  /**
   * 定期ポーリング → Flow（ms ごとに GET を繰り返し emit し続ける）
   *
   * 使用例（AetherScript）:
   *   flow ticker = http.pollFlow("https://api.example.com/price", 5000)
   *   ticker.subscribe(fn(v) { print(v) })
   *
   * @param {string} url
   * @param {number} ms      - ポーリング間隔（ミリ秒）
   * @param {object} options
   * @returns {Flow}         unsubscribe で自動停止
   */
  pollFlow(url, ms = 5000, options = {}) {
    const flow = new Flow();

    // ポーリングの実行本体
    const poll = async () => {
      try {
        const body = await httpModule.get(url, options);
        flow.emit(body);
      } catch (err) {
        console.error('[http.pollFlow] エラー:', err.message);
        // エラーは emit せず継続（一時的な障害を無視）
      }
    };

    // 初回即時実行 → 以後インターバル
    poll();
    const timer = setInterval(poll, ms);

    // subscriber がゼロになったら（unsubscribe されたら）ポーリング停止
    flow._addCleanup(() => clearInterval(timer));

    return flow;
  },
};

module.exports = { httpModule };
