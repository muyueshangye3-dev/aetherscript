/**
 * AetherScript Interpreter v2
 * AST を直接実行する
 */

const fs   = require('fs');
const path = require('path');
const { Flow, interval } = require('./flow');
const { parseAetherScript } = require('./parser');
const { STDLIB }            = require('./stdlib');

// return 値をスタックを通じて伝搬するセンチネル
class ReturnSignal   { constructor(value) { this.value = value; } }
class BreakSignal    {}
class ContinueSignal {}

// ─── AetherError ─────────────────────────────────────────────────

/**
 * AetherScript 実行時エラー
 * JS の Error を継承し、ソース位置情報（line/col）とソースコードを保持する。
 * CLI / REPL で表示するときに該当行をハイライトできる。
 */
class AetherError extends Error {
  constructor(message, { line, col, src, cause } = {}) {
    super(message);
    this.name    = 'AetherError';
    this.line    = line  ?? null;
    this.col     = col   ?? null;
    this.srcText = src   ?? null;
    if (cause) this.cause = cause;
  }
}

/**
 * エラーメッセージを人間が読みやすい形式にフォーマットする
 *
 * 例:
 *   [AetherScript Error] 未定義の変数: z
 *   --> main.ae  3:8
 *    3 | print(z)
 *               ^
 *
 * @param {Error}  err      - エラーオブジェクト
 * @param {string} filePath - 実行中ファイルのパス（表示用）
 * @param {string} src      - ソースコード全体（行ハイライト用）
 * @returns {string}
 */
function formatError(err, filePath = '<script>', src = '') {
  const lines = [];

  // ヘッダー
  lines.push(`\x1b[31m[AetherScript Error]\x1b[0m ${err.message}`);

  const line = err.line ?? null;
  const col  = err.col  ?? null;

  if (line !== null) {
    // ファイル位置
    lines.push(`  \x1b[36m-->\x1b[0m ${filePath}  ${line}:${col ?? 1}`);

    // ソース行を表示（srcText 優先、なければ引数の src から取る）
    const srcLines = (err.srcText || src).split('\n');
    const srcLine  = srcLines[line - 1] ?? '';

    const lineNum   = String(line).padStart(4);
    const gutterSep = ' \x1b[36m|\x1b[0m ';
    lines.push(`${lineNum}${gutterSep}${srcLine}`);

    // カーソル ^ を列位置に合わせる
    if (col !== null) {
      const pad    = ' '.repeat(4 + 3 + (col - 1));  // lineNum + " | " + offset
      const caret  = '\x1b[31m^\x1b[0m';
      lines.push(`${pad}${caret}`);
    }
  }

  return lines.join('\n');
}

// ─── 型チェック ───────────────────────────────────────────────────

/**
 * 有効な型名セット
 * any は常にパスするワイルドカード
 */
const VALID_TYPES = new Set(['number', 'string', 'boolean', 'flow', 'any']);

/**
 * 値が型アノテーションと一致するか検証する
 * 不一致なら AetherError をスローする
 *
 * @param {*}      value    - チェック対象の値
 * @param {string} typeName - 期待する型名（null なら チェックしない）
 * @param {string} context  - エラーメッセージ用のコンテキスト（変数名など）
 * @param {object} loc      - { line, col } 位置情報（省略可）
 */
function checkType(value, typeName, context = '', loc = {}) {
  if (!typeName || typeName === 'any') return;

  const actual = resolveType(value);
  if (actual !== typeName) {
    throw new AetherError(
      `型エラー${context ? ` [${context}]` : ''}: "${typeName}" が必要ですが "${actual}" が渡されました`,
      { line: loc.line ?? null, col: loc.col ?? null }
    );
  }
}

/**
 * JavaScript の値から AetherScript の型名を導出する
 * @param {*} value
 * @returns {string} 型名
 */
function resolveType(value) {
  if (value === null || value === undefined)                         return 'null';
  if (value instanceof Flow)                                         return 'flow';
  if (typeof value === 'number')                                     return 'number';
  if (typeof value === 'string')                                     return 'string';
  if (typeof value === 'boolean')                                    return 'boolean';
  if (typeof value === 'function')                                   return 'function';
  return 'object';
}

// ─── ModuleLoader ─────────────────────────────────────────────────

/**
 * モジュールのロード・キャッシュを一元管理する
 * ひとつのロード処理中は「ロード中セット」で循環importを検出する
 */
class ModuleLoader {
  constructor() {
    this._cache    = new Map(); // absPath → エクスポートオブジェクト
    this._loading  = new Set(); // 現在ロード中のパス（循環検出用）
  }

  /**
   * モジュールをロードしてエクスポートオブジェクトを返す
   * @param {string} source   - モジュール名 or パス文字列（AST の source）
   * @param {string} basePath - 呼び出し元ファイルのディレクトリ
   */
  async load(source, basePath) {
    // ① "@math" など @ プレフィックスは stdlib を強制参照（ローカルより優先）
    if (source.startsWith('@')) {
      const stdName = source.slice(1);
      if (STDLIB.has(stdName)) return STDLIB.get(stdName);
      throw new Error(`標準ライブラリ "${stdName}" は存在しません`);
    }

    // ② ローカルファイルが存在すればそちらを優先する
    //    （stdlib と同名のユーザーモジュールを上書きできる）
    const absPath     = this._resolve(source, basePath);
    const localExists = (() => {
      try { require('fs').accessSync(absPath); return true; }
      catch { return false; }
    })();

    // ③ ローカルファイルなし → ネイティブ標準ライブラリを返す
    if (!localExists) {
      if (STDLIB.has(source)) return STDLIB.get(source);
      throw new Error(`importファイルが見つかりません: ${absPath}`);
    }

    // ④ キャッシュヒット → そのまま返す
    if (this._cache.has(absPath)) return this._cache.get(absPath);

    // ⑤ 循環 import 検出
    if (this._loading.has(absPath)) {
      throw new Error(`循環importを検出しました: ${absPath}`);
    }

    // ⑥ ファイル読み込み
    let src;
    try {
      src = fs.readFileSync(absPath, 'utf8');
    } catch (e) {
      throw new Error(`importファイルが見つかりません: ${absPath}`);
    }

    // ⑦ parse → 独立した env で非同期実行
    this._loading.add(absPath);
    const ast       = parseAetherScript(src);
    const moduleEnv = createGlobalEnv(this, path.dirname(absPath));
    await evalNode({ type: 'Program', body: ast.body }, moduleEnv);

    const exports = collectExports(moduleEnv);
    this._loading.delete(absPath);
    this._cache.set(absPath, exports);
    return exports;
  }

  /**
   * source 文字列 → 絶対パスに解決
   *
   * 探索優先順位:
   *   1. ./ や ../ で始まる → 相対パスとして直接解決
   *   2. modules/<source>/index.ae が存在する → パッケージとして解決
   *   3. basePath 直下の <source>.ae → 従来の動作
   */
  _resolve(source, basePath) {
    // ① 明示的な相対パス → そのまま解決
    if (source.startsWith('./') || source.startsWith('../')) {
      const withExt = source.endsWith('.ae') ? source : `${source}.ae`;
      return path.resolve(basePath, withExt);
    }

    // ② modules/<source>/index.ae を探す（インストール済みパッケージ）
    //    basePath から上方向へ modules/ を探す（最大3階層）
    let searchDir = basePath;
    for (let i = 0; i < 3; i++) {
      const pkgIndex = path.join(searchDir, 'modules', source, 'index.ae');
      if (fs.existsSync(pkgIndex)) return pkgIndex;
      const parent = path.dirname(searchDir);
      if (parent === searchDir) break;   // ルートに達したら停止
      searchDir = parent;
    }

    // ③ basePath 直下の <source>.ae（従来動作・後方互換）
    const withExt = source.endsWith('.ae') ? source : `${source}.ae`;
    return path.resolve(basePath, withExt);
  }
}

/**
 * env から組み込みキーを除いたエクスポートオブジェクトを作る
 * prototype チェーン上のキーは除外する（Object.create(null) 由来のもの以外）
 */
function collectExports(env) {
  const BUILTINS = new Set(['interval', 'print', '__basePath__']);
  const exports  = {};
  for (const key of Object.keys(env)) {
    if (!BUILTINS.has(key)) exports[key] = env[key];
  }
  return exports;
}

// グローバルに使い回す ModuleLoader インスタンス
const globalLoader = new ModuleLoader();

/**
 * ASTノードを評価する（async）
 *
 * 全ノードで await を通すことで、関数が Promise を返しても
 * 呼び出し元は透過的に値を受け取れる。
 * 同期値に await しても単にそのまま返るため、既存の動作は変わらない。
 */
async function evalNode(node, env) {
  switch (node.type) {

    case 'Program': {
      let result;
      for (const stmt of node.body) {
        result = await evalNode(stmt, env);
        // ReturnSignal / BreakSignal / ContinueSignal はすべて上位へ伝搬
        if (result instanceof ReturnSignal)   return result;
        if (result instanceof BreakSignal)    return result;
        if (result instanceof ContinueSignal) return result;
      }
      return result;
    }

    case 'NumberLiteral': return node.value;
    case 'StringLiteral': return node.value;
    case 'BoolLiteral':   return node.value;   // true / false
    case 'NullLiteral':   return null;          // null

    case 'Identifier': {
      if (!(node.name in env)) {
        const e = new AetherError(
          `未定義の変数: ${node.name}`,
          { line: node.line, col: node.col }
        );
        throw e;
      }
      return env[node.name];
    }

    case 'VarDecl': {
      const value = await evalNode(node.init, env);
      checkType(value, node.typeAnnotation, node.name, { line: node.line, col: node.col });
      env[node.name] = value;
      return value;
    }

    /**
     * 再代入: x = expr
     * スコープチェーンを上方向に探して最初に見つかったスコープに書き込む
     * 見つからなければ現在スコープに新規作成（グローバル的動作）
     */
    case 'AssignStmt': {
      const value = await evalNode(node.value, env);
      // プロトタイプチェーンを辿って宣言済みスコープを探す
      let scope = env;
      while (scope !== null) {
        if (Object.prototype.hasOwnProperty.call(scope, node.name)) {
          scope[node.name] = value;
          return value;
        }
        scope = Object.getPrototypeOf(scope);
      }
      // 見つからなければ現在スコープに作成
      env[node.name] = value;
      return value;
    }

    /**
     * インデックス代入: arr[i] = expr
     */
    case 'IndexAssignStmt': {
      const obj   = await evalNode(node.object, env);
      const index = await evalNode(node.index,  env);
      const value = await evalNode(node.value,  env);
      if (!Array.isArray(obj) && typeof obj !== 'object') {
        throw new TypeError('インデックス代入: 配列かオブジェクトに対してのみ使用できます');
      }
      obj[index] = value;
      return value;
    }

    /**
     * 変数再代入: name = expr
     * スコープチェーンを辿って既存の定義を上書きする。
     * 見つからなければ現スコープに新規作成する。
     */
    case 'AssignStmt': {
      const value = await evalNode(node.value, env);
      let scope = env;
      while (scope !== null) {
        if (Object.prototype.hasOwnProperty.call(scope, node.name)) {
          scope[node.name] = value;
          return value;
        }
        scope = Object.getPrototypeOf(scope);
      }
      env[node.name] = value;
      return value;
    }

    // name += expr  →  name = name + expr に展開
    case 'CompoundAssign': {
      const current = env[node.name];
      const rhs     = await evalNode(node.value, env);
      const opBase  = node.op[0];   // '+=' → '+'
      let result;
      if      (opBase === '+') result = current + rhs;
      else if (opBase === '-') result = current - rhs;
      else if (opBase === '*') result = current * rhs;
      else if (opBase === '/') result = current / rhs;
      else throw new SyntaxError(`未対応の複合代入演算子: ${node.op}`);
      // スコープチェーンを辿って上書き
      let scope = env;
      while (scope !== null) {
        if (Object.prototype.hasOwnProperty.call(scope, node.name)) { scope[node.name] = result; return result; }
        scope = Object.getPrototypeOf(scope);
      }
      env[node.name] = result;
      return result;
    }

    // name++  /  name--
    case 'IncDecStmt': {
      const cur = env[node.name];
      const next = node.op === '++' ? cur + 1 : cur - 1;
      let scope = env;
      while (scope !== null) {
        if (Object.prototype.hasOwnProperty.call(scope, node.name)) { scope[node.name] = next; return cur; }
        scope = Object.getPrototypeOf(scope);
      }
      env[node.name] = next;
      return cur;
    }

    // switch (expr) { case v: ... break  default: ... }
    case 'SwitchStmt': {
      const val     = await evalNode(node.expr, env);
      let matched   = false;
      for (const c of node.cases) {
        if (!matched) {
          if (c.value === null) { matched = true; }           // default
          else {
            const cv = await evalNode(c.value, env);
            if (val === cv) matched = true;
          }
        }
        if (matched) {
          const result = await evalNode({ type: 'Program', body: c.body }, env);
          if (result instanceof ReturnSignal)   return result;   // 関数returnは貫通
          if (result instanceof ContinueSignal) return result;   // ループcontinueは貫通
          if (result instanceof BreakSignal)    return undefined; // breakはswitchで消費
        }
      }
      return undefined;
    }

    // `hello ${name}` → 各 part を評価して文字列連結
    case 'TemplateLiteral': {
      const pieces = await Promise.all(node.parts.map(p => evalNode(p, env)));
      return pieces.map(p => (p === null || p === undefined ? '' : String(p))).join('');
    }

    case 'BinaryExpr': {
      // || と && は短絡評価（右辺を評価するかどうかは左辺次第）
      if (node.op === '||') {
        const left = await evalNode(node.left, env);
        return left ? left : await evalNode(node.right, env);
      }
      if (node.op === '&&') {
        const left = await evalNode(node.left, env);
        return left ? await evalNode(node.right, env) : left;
      }

      // それ以外は両辺を並行評価
      const [left, right] = await Promise.all([
        evalNode(node.left,  env),
        evalNode(node.right, env),
      ]);
      switch (node.op) {
        // 算術
        case '+': return left + right;
        case '-': return left - right;
        case '*': return left * right;
        case '/': {
          if (right === 0) throw new RangeError('ゼロ除算');
          return left / right;
        }
        // 比較
        case '==': return left == right;   // 緩い等値（undefined == null → true）
        case '!=': return left != right;
        case '<':  return left <   right;
        case '>':  return left >   right;
        case '<=': return left <=  right;
        case '>=': return left >=  right;

        default: throw new SyntaxError(`未対応の演算子: ${node.op}`);
      }
    }

    /**
     * 単項演算子: !expr
     * 現在は ! のみ（将来 - の単項にも対応しやすい構造）
     */
    case 'UnaryExpr': {
      const operand = await evalNode(node.operand, env);
      if (node.op === '!') return !operand;
      if (node.op === '-') return -operand;
      throw new SyntaxError(`未対応の単項演算子: ${node.op}`);
    }

    /**
     * if / else if / else
     * condition が truthy なら thenBody、そうでなければ elseBody を実行する
     * ReturnSignal はそのまま上位へ伝搬する
     */
    case 'IfStmt': {
      const cond = await evalNode(node.condition, env);
      if (cond) {
        const result = await evalNode({ type: 'Program', body: node.thenBody }, env);
        if (result instanceof ReturnSignal || result instanceof BreakSignal || result instanceof ContinueSignal) return result;
      } else if (node.elseBody) {
        const result = await evalNode({ type: 'Program', body: node.elseBody }, env);
        if (result instanceof ReturnSignal || result instanceof BreakSignal || result instanceof ContinueSignal) return result;
      }
      return undefined;
    }

    /**
     * while (condition) { body }
     * - condition が falsy になるまでループ
     * - body 内の ReturnSignal はそのまま上位へ伝搬（関数からの return を貫通）
     * - 非同期 body も正しく await して直列実行する
     */
    case 'WhileStmt': {
      while (true) {
        const cond = await evalNode(node.condition, env);
        if (!cond) break;
        const result = await evalNode({ type: 'Program', body: node.body }, env);
        if (result instanceof ReturnSignal)   return result;
        if (result instanceof BreakSignal)    break;
        if (result instanceof ContinueSignal) continue;
      }
      return undefined;
    }

    case 'ForStmt': {
      if (node.init) await evalNode(node.init, env);
      while (true) {
        if (node.condition) {
          const cond = await evalNode(node.condition, env);
          if (!cond) break;
        }
        const result = await evalNode({ type: 'Program', body: node.body }, env);
        if (result instanceof ReturnSignal)   return result;
        if (result instanceof BreakSignal)    break;
        if (result instanceof ContinueSignal) { if (node.update) await evalNode(node.update, env); continue; }
        if (node.update) await evalNode(node.update, env);
      }
      return undefined;
    }

    /**
     * for (let x of arr) { body }
     * 配列・文字列のイテレーション。break / continue / return に対応。
     */
    case 'ForOfStmt': {
      const iterable = await evalNode(node.iterable, env);
      if (!iterable || typeof iterable[Symbol.iterator] !== 'function') {
        throw new AetherError(`for...of: イテラブルでない値が渡されました (${typeof iterable})`);
      }
      for (const item of iterable) {
        // ループ変数のみを env に直接バインド（外側スコープを共有）
        env[node.varName] = item;
        const result = await evalNode({ type: 'Program', body: node.body }, env);
        if (result instanceof ReturnSignal)   return result;
        if (result instanceof BreakSignal)    break;
        if (result instanceof ContinueSignal) continue;
      }
      return undefined;
    }

    /**
     * 配列分割代入: let [a, b, c] = [1, 2, 3]
     * 右辺の配列要素を順に各変数にバインドする
     */
    case 'ArrayDestructure': {
      const arr = await evalNode(node.init, env);
      if (!Array.isArray(arr)) {
        throw new AetherError(`分割代入: 右辺は配列が必要です (got ${typeof arr})`,
          { line: node.line, col: node.col });
      }
      node.names.forEach((name, i) => { env[name] = arr[i] ?? null; });
      return arr;
    }

    case 'BreakStmt':    return new BreakSignal();
    case 'ContinueStmt': return new ContinueSignal();

    case 'FunctionDecl': {
      const fn = async (...args) => {
        const localEnv = Object.create(env);

        for (let i = 0; i < node.params.length; i++) {
          const param     = node.params[i];
          const paramName = typeof param === 'string' ? param : param.name;
          const paramType = typeof param === 'string' ? null  : param.typeAnnotation;

          if (param.rest) {
            // ...args → 残りを配列として束縛（型チェックなし）
            localEnv[paramName] = args.slice(i);
            break;
          }

          const supplied = args[i] !== undefined ? args[i] : null;
          if (args[i] === undefined && param.defaultValue) {
            localEnv[paramName] = await evalNode(param.defaultValue, localEnv);
          } else {
            // param に位置情報があれば渡す（パーサーが付与したもの）
            checkType(supplied, paramType, `引数 ${paramName}`,
              { line: param.line, col: param.col });
            localEnv[paramName] = supplied;
          }
        }

        const result = await evalNode({ type: 'Program', body: node.body }, localEnv);
        // ReturnSignal は値を取り出す
        // BreakSignal / ContinueSignal は関数境界で消費（上位には漏らさない）
        let retVal;
        if      (result instanceof ReturnSignal)   retVal = result.value;
        else if (result instanceof BreakSignal)    retVal = undefined;
        else if (result instanceof ContinueSignal) retVal = undefined;
        else                                       retVal = result;
        checkType(retVal, node.returnType, `${node.name || '無名関数'} の戻り値`,
          { line: node.line, col: node.col });
        return retVal;
      };
      if (node.name) env[node.name] = fn;
      return fn;
    }

    case 'ReturnStmt': {
      const value = node.value ? await evalNode(node.value, env) : undefined;
      return new ReturnSignal(value);
    }

    case 'CallExpr': {
      if (node.callee.type === 'Identifier') {
        const fn = env[node.callee.name];
        if (typeof fn !== 'function') {
          throw new AetherError(
            `"${node.callee.name}" は関数ではありません`,
            { line: node.callee.line, col: node.callee.col }
          );
        }
        const args = await Promise.all(node.args.map(a => evalNode(a, env)));
        return await fn(...args);
      }
      if (node.callee.type === 'MemberExpr') {
        const obj    = await evalNode(node.callee.object, env);
        const method = node.callee.property;
        if (typeof obj[method] !== 'function') {
          throw new AetherError(
            `"${method}" はメソッドではありません`,
            { line: node.callee.line, col: node.callee.col }
          );
        }
        const args = await Promise.all(node.args.map(a => evalNode(a, env)));
        return await obj[method](...args);
      }
      throw new SyntaxError(`未対応のCallExpr callee: ${node.callee.type}`);
    }

    case 'MemberExpr': {
      const obj = await evalNode(node.object, env);
      return obj[node.property];
    }

    /**
     * 配列リテラル: [1, 2, 3]
     * 各要素を順番に評価して JS 配列を作る
     */
    case 'ArrayLiteral': {
      const elements = [];
      for (const el of node.elements) {
        elements.push(await evalNode(el, env));
      }
      return elements;
    }

    /**
     * インデックスアクセス: arr[0]  arr[i]
     * 文字列にも使える: "hello"[1] → "e"
     */
    case 'IndexExpr': {
      const obj   = await evalNode(node.object, env);
      const index = await evalNode(node.index,  env);
      if (obj === null || obj === undefined) {
        throw new TypeError(`インデックスアクセス: null/undefined には添字アクセスできません`);
      }
      return obj[index];
    }

    /**
     * オブジェクトリテラル: { name: "ae", version: 1 }
     * 各 value を順番に評価して JS plain object を作る
     */
    case 'ObjectLiteral': {
      const obj = {};
      for (const prop of node.properties) {
        if (prop.spread) {
          // { ...src } → src の全プロパティをコピー
          const src = await evalNode(prop.value, env);
          if (src && typeof src === 'object') Object.assign(obj, src);
        } else {
          obj[prop.key] = await evalNode(prop.value, env);
        }
      }
      return obj;
    }

    /**
     * for (init; condition; update) { body }
     * - init を1回実行
     * - condition が truthy な間、body → update を繰り返す
     * - ReturnSignal はそのまま上位へ伝搬する
     */
    case 'ForStmt': {
      // init（let 宣言 or 代入）
      if (node.init) await evalNode(node.init, env);

      while (true) {
        // condition が null（省略）なら無限ループ
        if (node.condition) {
          const cond = await evalNode(node.condition, env);
          if (!cond) break;
        }
        const result = await evalNode({ type: 'Program', body: node.body }, env);
        if (result instanceof ReturnSignal || result instanceof BreakSignal || result instanceof ContinueSignal) return result;

        // update（i = i + 1 など）
        if (node.update) await evalNode(node.update, env);
      }
      return undefined;
    }

    case 'FlowDecl': {
      const flow = await evalNode(node.init, env);
      if (!(flow instanceof Flow)) throw new TypeError('FlowDeclの右辺がFlowではありません');
      env[node.name] = flow;
      return flow;
    }

    case 'ImportDecl': {
      const basePath = env.__basePath__ || process.cwd();
      // ModuleLoader.load は同期（.ae ファイル読み込み）のままでよい
      const exports  = await globalLoader.load(node.source, basePath);
      env[node.name] = exports;
      return exports;
    }

    /**
     * try { ... } catch (e) { ... }
     *
     * - tryBody を await 実行する
     * - 同期・非同期どちらの例外も catch できる（evalNode が async なので透過）
     * - catch ブロックはローカルスコープに catchVar をバインドして実行
     * - ReturnSignal は例外ではないので catch せずそのまま伝搬する
     */
    case 'TryCatchStmt': {
      try {
        const result = await evalNode({ type: 'Program', body: node.tryBody }, env);
        // try 内で return があれば ReturnSignal が返る → そのまま上位に伝搬
        if (result instanceof ReturnSignal || result instanceof BreakSignal || result instanceof ContinueSignal) return result;
      } catch (err) {
        // catch ブロック用のローカルスコープを作り、catchVar にエラーを代入
        const catchEnv = Object.create(env);

        // エラー値: AetherScript では文字列・オブジェクト両方投げられる
        // message プロパティがあれば文字列として、なければそのまま代入
        catchEnv[node.catchVar] = (err instanceof Error) ? err.message : err;

        const result = await evalNode({ type: 'Program', body: node.catchBody }, catchEnv);
        if (result instanceof ReturnSignal || result instanceof BreakSignal || result instanceof ContinueSignal) return result;
      }
      return undefined;
    }

    /**
     * throw expression
     *
     * 評価した値を JS の throw で投げる。
     * - 文字列を throw → catch (e) で文字列として受け取れる
     * - 上位の TryCatchStmt か JS の try-catch（CLI の fatal）で捕捉される
     */
    case 'ThrowStmt': {
      const value = node.value ? await evalNode(node.value, env) : undefined;
      // 文字列なら Error にラップして stack trace を保持する
      throw (typeof value === 'string') ? new Error(value) : value;
    }

    default:
      throw new SyntaxError(`未知のASTノード: ${node.type}`);
  }
}

/**
 * グローバルスコープ（組み込み関数を登録）
 * @param {ModuleLoader} loader   - モジュールローダー（import処理用）
 * @param {string}       basePath - このファイルのディレクトリ（相対import解決用）
 */
function createGlobalEnv(loader = globalLoader, basePath = process.cwd()) {
  return {
    __basePath__: basePath,
    interval,
    print: (...args) => console.log(...args),

    /**
     * Promise → Flow 変換
     * Promiseが解決したとき1度だけ値をemitするFlowを返す
     *
     * 使用例（AetherScript）:
     *   flow result = fromPromise(time.sleep(1000))
     *   result.subscribe(fn(v) { print(v) })
     */
    fromPromise(promise) {
      const flow = new Flow();
      Promise.resolve(promise)
        .then(value  => { flow.emit(value); })
        .catch(err   => { console.error('[fromPromise] エラー:', err.message); });
      return flow;
    },
  };
}

/**
 * AST を実行するエントリポイント（async）
 * @param {Object} ast
 * @param {string} filePath - 実行ファイルの絶対パス（import解決の起点）
 * @returns {Promise<*>}
 */
async function run(ast, filePath = process.cwd()) {
  const basePath = path.extname(filePath) ? path.dirname(filePath) : filePath;
  const env = createGlobalEnv(globalLoader, basePath);
  return evalNode(ast, env);
}

module.exports = { run, evalNode, createGlobalEnv, AetherError, formatError };
